<?php 

    $cod_producto = $_GET["id"];
    
    require("conn.php");      
    $conn = mysqli_connect($db_server,$db_user,$db_password,$db_database);
    $script = "DELETE from productos where cod_producto = '$cod_producto'";
    $query_result = mysqli_query($conn,$script);

    if($query_result==true)
    {
        header("Location:formulario.php?id_alumno=" . $cod_producto);
    } else
        {
            echo "Error al eliminar los datos";
        }    
mysqli_close($conn)

?>

