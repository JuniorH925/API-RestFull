<?php 
    $db_server = "localhost";
    $db_database = "db_productos";
    $db_user = "root";
    $db_password = "";

    $conn = mysqli_connect($db_server,$db_user,$db_password,$db_database);
?>