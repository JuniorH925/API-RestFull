<?php 
 require("conn.php");      
 $conn = mysqli_connect($db_server, $db_user, $db_password, $db_database);
 $script = "SELECT * FROM productos";
 $query_result = mysqli_query($conn, $script); 

    // Verificar si se encontró un producto con el ID especificado
    if ($query_result && $fila = mysqli_fetch_assoc($query_result)) {
        $cod_producto = $fila["cod_producto"];
        $descripcion = $fila["descripcion"];
        $lote = $fila["lote"];
        $unidad_medida = $fila["unidad_medida"];
        $fecha_ingreso = $fila["fecha_ingreso"];
        $fecha_vencimiento = $fila["fecha_vencimiento"];
        $precio = $fila["precio"];
    } else {
        echo "No se encontró un producto con ese ID.";
        exit; // Salir del script si no se encontró un producto
    }
?>

<?php require "templates/header.php"; ?>
<div class="container">
    <div class="row">
      <div class="col-md-12">
        <h2 class="mt-4">Editando producto <?= $descripcion ?></h2>
        <hr>
        <form method="post">
          <div class="form-group">
            <label for="cod_producto">Codigo de producto</label>
            <input type="text" name="cod_producto" id="cod_producto" value="<?= $cod_producto ?>" class="form-control" readonly>
          </div>
         <div class="form-group">
            <label for="descripcion">Descripción</label>
            <input type="text" name="descripcion" id="descripcion" value="<?= $descripcion ?>" class="form-control">
          </div>
          <div class="form-group">
            <label for="lote">Lote</label>
            <input type="text" name="lote" id="lote" value="<?= $lote ?>" class="form-control">
          </div>
          <div class="form-group">
            <label for="unidad_medida">Unidad de medida</label>
            <input type="text" name="unidad_medida" id="unidad_medida" value="<?= $unidad_medida ?>" class="form-control">
          </div>
          <div class="form-group">
            <label for="fecha_ingreso">Fecha de ingreso</label>
            <input type="date" name="fecha_ingreso" id="fecha_ingreso" value="<?= $fecha_ingreso ?>" class="form-control">
          </div>
          <div class="form-group">
            <label for="fecha_vencimiento">Fecha de vencimiento</label>
            <input type="date" name="fecha_vencimiento" id="fecha_vencimiento" value="<?= $fecha_vencimiento ?>" class="form-control">
          </div>
          <div class="form-group">
            <label for="precio">Precio</label>
            <input type="text" name="precio" id="precio" value="<?= $precio ?>" class="form-control">
          </div>
          <div class="form-group">
            <input type="submit" name="submit" class="btn btn-primary" value="Actualizar">
            <a class="btn btn-primary" href="formulario.php">Regresar al inicio</a>
          </div>
        </form>
      </div>
    </div>
</div>
<?php require "templates/footer.php"; ?>

<?php 
if (isset($_POST["submit"])) 
{
    $cod_producto = $_POST['cod_producto']; // Selecciona el campo correcto
    $descripcion = $_POST['descripcion'];
    $lote = $_POST['lote'];
    $unidad_medida = $_POST["unidad_medida"];
    $fecha_ingreso = $_POST["fecha_ingreso"];
    $fecha_vencimiento = $_POST["fecha_vencimiento"];
    $precio = $_POST["precio"];

    $script = "UPDATE productos 
                SET descripcion = '$descripcion', 
                lote = '$lote', 
                unidad_medida = '$unidad_medida', 
                fecha_ingreso = '$fecha_ingreso', 
                fecha_vencimiento = '$fecha_vencimiento',
                precio = '$precio'
                WHERE cod_producto = '$cod_producto'";

    $query_result = mysqli_query($conn, $script);

    if ($query_result) 
    {
        mysqli_close($conn);
        header("Location: formulario.php?cod_producto=" . $cod_producto);
    } else {
        echo "Registro no se logró editar en la base de datos";
    }

    mysqli_close($conn);
}
?>
