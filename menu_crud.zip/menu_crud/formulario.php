<?php
require("conn.php");
$conn = mysqli_connect($db_server, $db_user, $db_password, $db_database);

if (mysqli_connect_errno()) {
    echo "error en el acceso a la base de datos";
}

if (isset($_POST['descripcion'])) {
    $script = "SELECT * FROM productos WHERE descripcion LIKE '%" . $_POST['descripcion'] . "%'";
} else {
    $script = "SELECT * FROM productos";
}
$query_result = mysqli_query($conn, $script);
?>

<?php $titulo = 'Lista de productos '; ?>
<?php include "templates/header.php"; ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <a href="crear.php" class="btn btn-primary mt-4">Crear producto</a>
            <hr>
            <form method="post" class="form-inline">
                <div class="form-group mr-3">
                    <input type="text" id="descripcion" name="descripcion" placeholder="Buscar por descripción" class="form-control">
                </div>
                <button type="submit" name="submit" class="btn btn-primary">Ver resultados</button>
            </form>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h2 class="mt-3"><?= $titulo ?></h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Código de producto</th>
                        <th>Descripción</th>
                        <th>Lote</th>
                        <th>Unidad de medida</th>
                        <th>Fecha de ingreso</th>
                        <th>Fecha de vencimiento</th>
                        <th>Precio</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($fila = mysqli_fetch_assoc($query_result)) {
                        ?>
                        <tr>
                            <td><?php echo ($fila["cod_producto"]); ?></td>
                            <td><?php echo ($fila["descripcion"]); ?></td>
                            <td><?php echo ($fila["lote"]); ?></td>
                            <td><?php echo ($fila["unidad_medida"]); ?></td>
                            <td><?php echo ($fila["fecha_ingreso"]); ?></td>
                            <td><?php echo ($fila["fecha_vencimiento"]); ?></td>
                            <td><?php echo ($fila["precio"]); ?></td>
                            <td>
                                <a href="<?= 'eliminar.php?id=' . ($fila["cod_producto"]) ?>">🗑️Borrar</a> 
                                <a href="<?= 'editar.php?id=' . ($fila["cod_producto"]) ?>">✏️Editar</a>

                                
                            </td>
                        </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include "templates/footer.php"; ?>
