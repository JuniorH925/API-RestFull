
<?php include 'templates/header.php'; ?>
<?php

 require("conn.php");      
$conn = mysqli_connect($db_server, $db_user, $db_password, $db_database);
$script = "SELECT * FROM unidad_medida";
$query_result = mysqli_query($conn, $script); 


    ?>

<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h2 class="mt-4">Crea un producto</h2>
      <hr>
      <form method="post">
        <div class="form-group">
          <label for="descripcion">Descripcion</label>
          <input type="text" name="descripcion" id="descripcion" class="form-control">
        </div>
        <div class="form-group">
          <label for="lote">Lote</label>
          <input type="text" name="lote" id="lote" class="form-control">
        </div>



        <div class="form-group">
            <div class="row">
                  <div class="col-md-4">
                    <select class="form-control" name="unidad_medida" id="unidad_medida">
                      <option value="">Seleccione la unidad de medida</option>
                    <?php  foreach($query_result as $vector): ?>
                      <option value="<?php echo (string)$vector['cod_um'] ?>">
                        <?php echo $vector['descripcion_um'] ?></option>
                    <?php endforeach; ?>
                    </select>
                  </div>
            </div>  
          </div>




        <div class="form-group">
          <label for="ex_parcial">Fecha de ingreso</label>
          <input type="date" name="fecha_ingreso" id="fecha_ingreso" class="form-control">
        </div>
        <div class="form-group">
          <label for="fecha_vencimiento">Fecha de vencimiento</label>
          <input type="date" name="fecha_vencimiento" id="fecha_vencimiento" class="form-control">
        </div>
        <div class="form-group">
          <label for="precio">Precio</label>
          <input type="number" step="0.01" name="precio" id="precio" class="form-control">
        </div>
        <div class="form-group">
          <input type="submit" name="submit" class="btn btn-primary" value="Enviar">
          <a class="btn btn-primary" href="formulario.php">Regresar al inicio</a>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include 'templates/footer.php'; ?>

<?php 
    if (isset($_POST["submit"])) 
    {
        $descripcion = $_POST['descripcion'];
        $lote = $_POST['lote'];
        $unidad_medida = $_POST["unidad_medida"];
        $fecha_ingreso = $_POST["fecha_ingreso"];
        $fecha_vencimiento = $_POST["fecha_vencimiento"];
        $precio = $_POST["precio"];

        require("conn.php");
        $conn = mysqli_connect($db_server,$db_user,$db_password,$db_database); 
        $scrip = "insert into productos (descripcion, lote, unidad_medida, fecha_ingreso, fecha_vencimiento, precio) values ('$descripcion', '$lote', '$unidad_medida','$fecha_ingreso','$fecha_vencimiento', '$precio');";  
        $sql_query = mysqli_query($conn,$scrip);
          
        if($sql_query==true)
        {
            header("Location:formulario.php?cod_producto=" . $cod_producto);
        } else
            {
                echo "Error al insertar datos";
            }    
    mysqli_close($conn);        
    }
?>